import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Controller implements ActionListener {

    private Viewer viewer;


    public Controller(Viewer viewer) {
        this.viewer = viewer;
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        switch (command) {
            case "Open_a_File":
                openFile();
                break;
            case "Save_a_Text_to_File":
                saveTextToFile();
                break;
            case "Delete_Text":
                DeleteText();
                break;
            case "Copy":

                viewer.copy();

                break;
            case "Cut":

                viewer.cut();

                break;
            case "Paste":
                viewer.paste();
                break;


            default:

        }
    }


    private void DeleteText() {
        System.out.println("1");
    }

    private void saveTextToFile() {
        File file = viewer.showFileChooserDialog("Save");
        String textForSave = viewer.getContent();
        PrintWriter outputStream = null;
        try {
            FileWriter fileWriter = new FileWriter(file);
            outputStream = new PrintWriter(fileWriter);
            outputStream.println(textForSave);
            outputStream.flush();
            outputStream.close();
            JOptionPane.showMessageDialog(viewer.getMainFrame(), "The text was saved a successful.");
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

    }

    /* private void openFile() {

         System.out.println("i am controller");
         File file = viewer.showFileChooserDialog();
         if (file != null){
             System.out.println(file);

             FileInputStream in = null;
             try {
                 in = new FileInputStream(file);
                 long sizeDile = file.length();
                 byte array[] = new byte[(int)sizeDile];
                 int index = 0;
                 int unicode;
                 while ((unicode = in.read()) != -1){
                     array[index] = (byte)unicode;
                     index = index -1;
                 }
                 viewer.update(array);
                 array = null;
                 in.close();

             }
             catch (FileNotFoundException fne){
                 System.out.println();
             }
             catch (IOException ioe){
                 System.out.println(ioe);
             }
         }*/
    private void openFile() {
        File file = viewer.showFileChooserDialog("Open");
        if (file != null) {
            BufferedReader inputStream = null;
            try {
                FileReader fileReader = new FileReader(file);
                inputStream = new BufferedReader(fileReader);
                List<String> list = new ArrayList<String>();
                String line;
                while ((line = inputStream.readLine()) != null) {
                    list.add(line);
                }
                String listString = String.join("\n", list);
                viewer.update(listString);
                list.clear();
                list = null;
                inputStream.close();
            } catch (FileNotFoundException fne) {
                System.out.println(fne);
            } catch (IOException ioe) {
                System.out.println(ioe);
            }

        }

    }
}

