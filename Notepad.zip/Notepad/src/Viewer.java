import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.List;

public class Viewer {
    private Controller controller;
    private JFrame frame;
    private JTextArea textArea;
    private JFileChooser fc;
    public Viewer(){
        controller = new Controller(this);

        //createMenuBar();
        //createCenterComponent();
        createFrame();

    }

    /*private void createCenterComponent() {
        System.out.println("Create Component");
    }*/
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(createFileMenu());
        menuBar.add(createEditMenu());
        menuBar.add(createFormatMenu());
        menuBar.add(createViewMenu());
        menuBar.add(createHelpMenu());
        return menuBar;
    }

    private JMenu createFileMenu(){

        JMenuItem newDocument = new  JMenuItem("New", new ImageIcon("image/new.gif"));
        newDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        newDocument.setActionCommand("New_Document");

        JMenuItem openDocument = new  JMenuItem("Open...", new ImageIcon("image/open.gif"));
        openDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        //openDocument.setActionCommand("Open");
        openDocument.addActionListener(controller);
        openDocument.setActionCommand("Open_a_File");

        JMenuItem saveDocument = new  JMenuItem("Save", new ImageIcon("image/save.gif"));
        saveDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        saveDocument.addActionListener(controller);
        saveDocument.setActionCommand("Save_a_Text_to_File");

        JMenuItem Save_As = new  JMenuItem("Save As...", new ImageIcon("image/save_as.gif"));
        //Save_As.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        Save_As.setActionCommand("Save_As");

        JMenuItem Print = new  JMenuItem("Print...", new ImageIcon("image/print.gif"));
        Print.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        Print.setActionCommand("Print");

        JMenuItem Exit = new  JMenuItem("Exit"/*, new ImageIcon("image/exit.gif")*/);
        //Exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        Exit.setActionCommand("Exit");


        JMenu menuFile = new JMenu("File");
        menuFile.add(newDocument);
        menuFile.add(openDocument);
        menuFile.add(saveDocument);
        menuFile.add(Save_As);
        menuFile.addSeparator();
        menuFile.add(Print);
        menuFile.addSeparator();
        menuFile.add(Exit);
        return menuFile;
    }

    private JMenu createEditMenu(){


        JMenuItem Undo = new  JMenuItem("Undo", new ImageIcon("image/back.gif"));
        Undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK));
        Undo.setActionCommand("Undo");

        JMenuItem Cut = new  JMenuItem("Cut", new ImageIcon("image/cut.gif"));
        Cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
        Cut.setActionCommand("Cut");
        Cut.addActionListener(controller);

        JMenuItem Copy = new  JMenuItem("Copy", new ImageIcon("image/copy.gif"));
        Copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
        Copy.setActionCommand("Copy");
        Copy.addActionListener(controller);
        //Copy.setActionCommand("Save_a_Text_to_File");

        JMenuItem Paste = new  JMenuItem("Paste", new ImageIcon("image/past.gif"));
        Paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
        Paste.setActionCommand("Paste");
        Paste.addActionListener(controller);

        JMenuItem Delete = new  JMenuItem("Delete", new ImageIcon("image/delit.gif"));
        Delete.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
        Delete.setActionCommand("Delete");
        Delete.addActionListener(controller);
        Delete.setActionCommand("Delete_Text");

        JMenuItem Search = new  JMenuItem("Search with Bing...", new ImageIcon("image/findMore.gif"));
        Search.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
        Search.setActionCommand("Search");

        JMenuItem Find = new  JMenuItem("Find...", new ImageIcon("image/find.gif"));
        Find.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
        Find.setActionCommand("Find");

        JMenuItem FindNext = new  JMenuItem("Find Next"/*, new ImageIcon("image/find.gif")*/);
        FindNext.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0));
        FindNext.setActionCommand("FindNext");

        JMenuItem FindPrevious = new  JMenuItem("Find Previous"/*, new ImageIcon("image/find.gif")*/);
        FindPrevious.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3, ActionEvent.CTRL_MASK));
        FindPrevious.setActionCommand("FindPrevious");

        JMenuItem Replace = new  JMenuItem("Replace..."/*, new ImageIcon("image/find.gif")*/);
        Replace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, ActionEvent.CTRL_MASK));
        Replace.setActionCommand("Replace");

        JMenuItem GoTo = new  JMenuItem("Go To...", new ImageIcon("image/go.gif"));
        GoTo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, ActionEvent.CTRL_MASK));
        GoTo.setActionCommand("GoTo");

        JMenuItem SelectAll = new  JMenuItem("Select All"/*, new ImageIcon("image/go.gif")*/);
        SelectAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
        SelectAll.setActionCommand("SelectAll");

        JMenuItem TimeDate = new  JMenuItem("Time/Date"/*, new ImageIcon("image/time.gif")*/);
        TimeDate.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
        TimeDate.setActionCommand("TimeDate");


        //JMenu editFile = new JMenu("Edit");
        JMenu menuEdit = new JMenu("Edit");
        menuEdit.add(Undo);
        menuEdit.addSeparator();
        menuEdit.add(Cut);
        menuEdit.add(Copy);
        menuEdit.add(Paste);
        menuEdit.add(Delete);
        menuEdit.addSeparator();
        menuEdit.add(Search);
        menuEdit.add(Find);
        menuEdit.add(FindNext);
        menuEdit.add(FindPrevious);
        menuEdit.add(Replace);
        menuEdit.add(GoTo);
        menuEdit.addSeparator();
        menuEdit.add(SelectAll);
        menuEdit.add(TimeDate);

        return menuEdit;
    }

    private JMenu createFormatMenu(){
        JMenuItem WordWrap = new  JMenuItem("Word Wrap"/*, new ImageIcon("image/go.gif")*/);
        //WordWrap.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
        WordWrap.setActionCommand("WordWrap");

        JMenuItem Font = new  JMenuItem("Font..."/*, new ImageIcon("image/time.gif")*/);
        //Font.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, ActionEvent.CTRL_MASK));
        Font.setActionCommand("Font");




        JMenu menuFormat = new JMenu("Format");
        menuFormat.add(WordWrap);
        menuFormat.add(Font);
        return menuFormat;
    }

    private JMenu createViewMenu(){
        JMenu Zoom = new  JMenu("Zoom");
        //Zoom.setActionCommand("Zoom");
        //vlojennyi menu
        JMenuItem ZoomIn = new  JMenuItem("Zoom In");
        ZoomIn.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_PLUS, ActionEvent.CTRL_MASK));
        ZoomIn.setActionCommand("ZoomIn");

        JMenuItem ZoomOut = new  JMenuItem("Zoom Out");
        ZoomOut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, ActionEvent.CTRL_MASK));
        ZoomOut.setActionCommand("ZoomOut");

        JMenuItem DefaultZoom = new  JMenuItem("Restore Default Zoom");
        DefaultZoom.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_0,ActionEvent.CTRL_MASK));
        DefaultZoom.setActionCommand("DefaultZoom");


        JCheckBox StatusBar = new JCheckBox("Status Bar");
        StatusBar.setActionCommand("StatusBar");
        JMenu menuView = new JMenu("View");

        menuView.add(Zoom);
        Zoom.add(ZoomIn);
        Zoom.add(ZoomOut);
        Zoom.add(DefaultZoom);
        menuView.add(StatusBar);
        return menuView;
    }

    private JMenu createHelpMenu(){
        JMenuItem ViewHelp = new  JMenuItem("View Help"/*, new ImageIcon("image/go.gif")*/);
        //ViewHelp.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, ActionEvent.CTRL_MASK));
        ViewHelp.setActionCommand("ViewHelp");

        JMenuItem SendFeedback = new  JMenuItem("Send Feedback"/*, new ImageIcon("image/go.gif")*/);
        //SendFeedback.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
        SendFeedback.setActionCommand("SendFeedback");

        JMenuItem AboutNotepad = new  JMenuItem("About Notepad"/*, new ImageIcon("image/time.gif")*/);
        //AboutNotepad.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, ActionEvent.CTRL_MASK));
        AboutNotepad.setActionCommand("AboutNotepad");


        JMenu menuHelp = new JMenu("Help");
        menuHelp.add(ViewHelp);
        menuHelp.add(SendFeedback);
        menuHelp.addSeparator();

        menuHelp.add(AboutNotepad);

        return menuHelp;
    }

    private void createFrame() {
        Font font = new Font("Arial", Font.PLAIN, 45);
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);

        textArea.setFont(font);
        System.out.println("Create Frame");
        //JButton b1 = new JButton("North");
        frame = new JFrame("Notepad");

        frame.setJMenuBar(createMenuBar());
        frame.setSize(600, 500);
        frame.setLocation(300,100);
        //frame.add("North", b1);
        frame.add("Center", scrollPane);
        frame.setVisible(true);
    }

  /*  public File showFileChooserDialog() {
        JFileChooser fc = new JFileChooser();
        int returnVal = fc.showOpenDialog(frame);
        if (returnVal == JFileChooser.APPROVE_OPTION){
            File file = fc.getSelectedFile();
            return file;
        }
        return null;
    }*/
    public File showFileChooserDialog(String command) {
        if(fc == null) {
            fc = new JFileChooser();
        }
        //JFileChooser fc = new JFileChooser();
        int returnVal = -1;
        if(command.equals("Open")) {
            returnVal = fc.showOpenDialog(frame);
        } else if(command.equals("Save")) {
            returnVal = fc.showSaveDialog(frame);
        }

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            return file;
        }
        return null;
    }

//    public void update(String array) {
//        try {
//            String text= new String(array, "UTF-8");
//            textArea.setText(text);
//        }
//        catch (UnsupportedEncodingException usee){
//            System.out.println(usee);
//        }
//
//    }
    public void update(String text) {
        textArea.setText(text);
    }


    public String getContent() {
        textArea.copy();
        return textArea.getText();

    }

    public JFrame getMainFrame() {
        return frame;
    }


    public void copy() {
        //System.out.println("uov");
        textArea.copy();
    }


    public void cut() {
        textArea.cut();
    }
    public void paste(){
        textArea.paste();
    }
}
